<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4acb769e74adb8726742ced0bbdeebdd',
      'native_key' => 'quasirobots',
      'filename' => 'modNamespace/fb90e6242bcd6506edc0cb47fec8e239.vehicle',
      'namespace' => 'quasirobots',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '292e32c5c492d0c9a5a81ec91db7d9af',
      'native_key' => 1,
      'filename' => 'modCategory/2669d97aa25da03f80e199bec7ad3b21.vehicle',
      'namespace' => 'quasirobots',
    ),
  ),
);